new Glide(".glide", {
	type: "carousel",
    focusAt: 'center',
}).mount()
